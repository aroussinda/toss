var score = 0;
var min=1;
var max=10;
var x;
x= Math.floor(
    Math.random() * (max- min + 1) + min)

var array = []; 

const Lvl4 = require('../models/lvl4')
const  cookieParser =require("cookie-parser")
var array = []; 
const index = (req, res, next) => {
    Lvl4.find()
    .then(response => {
        res.json({
            response
        })
    })
    .catch(error => {
        res.json({
            message: 'An error Occured!'
        })
    })
}
const scoreFUN =(req,res,next)=>
{
    res.json({
        score
    })
}
const show = (req, res, next) => {
    let lvl4ID = req.body.lvlID
    Lvl4.findById(lvl4ID)
    .then(response => {
        res.json({
            response
        })
    })
    .catch(error => {
        res.json({
                   message: 'An error Occured'
 
        })
    })
}
const store = (req, res, next) => {
    var x=10;

    const useriden = req.cookies.UserID;

    let lvl4 = new Lvl4({
        question1: req.body.question1,
        answer1: req.body.answer1,
        question2: req.body.question2,
        answer2: req.body.answer2,
        question3: req.body.question3,
        answer3: req.body.answer3,
        question4: req.body.question4,
        answer4: req.body.answer4,
        question5: req.body.question5,
        answer5: req.body.answer5,
        question6: req.body.question6,
        answer6: req.body.answer6,
        question7 : req.body.question7,
        answer7 : req.body.answer7,
        question8 : req.body.question8,
        answer8: req.body.answer8,
        question9: req.body.question9,
        answer9 : req.body.answer9,
        question10: req.body.question10,
        answer10 : req.body.answer10

    })
    lvl4.iduser = useriden;
    lvl4.nbrstore= x;
    lvl4.save()
   .then(response => 
    {
        res.json({
            message:'lvl4 Added Successfully'
        })

    })
    .catch(error => {
        res.json({
            message:'An error Occured!'
        })
    })
   
}
const update = (req, res, next) => {
    let lvl4ID = req.body.lvlID

    let updatedData = {
        iduser: req.body.iduser,
        question1: req.body.question1,
        answer1: req.body.answer1,
        question2: req.body.question2,
        answer2: req.body.answer2,
        question3: req.body.question3,
        answer3: req.body.answer3,
        question4: req.body.question4,
        answer4: req.body.answer4,
        question5: req.body.question5,
        answer5: req.body.answer5,
        question6: req.body.question6,
        answer6: req.body.answer6,
        question7 : req.body.question7,
        answer7 : req.body.answer7,
        question8 : req.body.question8,
        answer8: req.body.answer8,
        question9: req.body.question9,
        answer9 : req.body.answer9,
        question10: req.body.question10,
        answer10 : req.body.answer10

    }
    Lvl4.findByIdAndUpdate(lvl4ID, {$set: updatedData})
    .then(() => {
        res.json({
            message:'lvl4 updated successfully!'
        })
    })
.catch(error => {
    res.json({
        message:'An error Occured!'
    })
})

}
const destroy =(req, res, next) =>{
    let lvl4ID = req.body.lvlID
    Lvl4.findByIdAndRemove(lvl4ID)
    .then(() => {
        res.json({
            message:'Lvl4 deleted successfully!'
        })
    })
    .catch (error => {
        res.json({
            messaage:'An error Occured'
        })
    })
}
const question = (req, res, next) =>
{
    var min=1;
var max=10;
x= Math.floor(
    Math.random() * (max- min + 1) + min)
    if(array.length<10)
{
array.unshift(x);
}
var question;
question="question"+x;
var Q1;
var responseNbr;

Lvl4.find()
.then(response => {
    var obj = JSON.stringify(response);
    var objectValue = JSON.parse(obj);
    responseNbr=objectValue[0]['nbrstore'] ;

     Q1=objectValue[0][question];
     if (responseNbr-array.length!=0 )
     {
 res.json({
     question:Q1
 })
     }
     else
     {
        res.json({
            message:"congratulations,level terminated successfully you can move on the next level or Redo it !!!!"          
               })   
     }    
     
})
.catch(error => {
    res.json({
        message: 'An error Occured!'
    })
})



}
const answer =(req, res , next) =>
{
    if(array.length<10)
{
array.unshift(x);
}
var responseNbr;
    const langue = req.cookies.langue;
    var useranswer = req.body.useranswer;
    var answer="answer"+x;
    var type;
    var A1;
   
    Lvl4.find()
    .then(response => {
        var obj = JSON.stringify(response);
        var objectValue = JSON.parse(obj);
        A1=objectValue[0][answer];
        responseNbr=objectValue[0]['nbrstore'] ;
        translate(A1, {to: langue})  .then(RT1 => {

            translate(useranswer, {to: langue})  .then(RT2 => {

                

                    if(RT2.text==RT1.text)
                      {
                      score=score+25;
                      type="your response was correct!!!!"
                      }
                      else
                      {
                          type ="you response was wrong!!!"
                          score= score-10;
                      }
                      if (responseNbr-array.length!=0 )
                      {
                          res.json({
                         
                         type,
                         score
                       }) 
                      }
                      else
                      {
                         res.json({
                             message:"your score is ",
                             score,
                             message:"congratulations,level terminated successfully you can move on the next level or Redo it !!!!"          
                                })   
                      }        
        
    })


  
})


 })
  .catch(error => {
        res.json({
            message: 'An error Occured!'
        })
    })
   
}
const pass=(req,res,next)=>
{
    if (score >=50)
    {
        res.json({
            message:"yes"
        })
    }
        else
        {
            res.json({
                message:"no"
            })
        }
    }




module.exports = {
    index, show, store, update, destroy, question, answer, scoreFUN, pass
}