//
//  match.swift
//  YassYes
//
//  Created by Mac-Mini-2021 on 13/11/2021.
//

import Foundation
struct Match:Codable{
    let ddd:Date
    let ddf:Date
    let equipe:[Equipe]
}
