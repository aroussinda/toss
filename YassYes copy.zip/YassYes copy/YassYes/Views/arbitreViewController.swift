//
//  arbitreViewController.swift
//  YassYes
//
//  Created by Mac2021 on 15/11/2021.
//

import UIKit

class arbitreViewController: UIViewController {
    
    
    @IBOutlet weak var imageArbitre: UIImageView!
    @IBOutlet weak var nomArbitre: UILabel!
    @IBOutlet weak var descArbitre: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func listeArbitresBtn(_ sender: Any) {
    }
    

}
