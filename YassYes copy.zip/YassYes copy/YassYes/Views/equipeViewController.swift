//
//  equipeViewController.swift
//  YassYes
//
//  Created by Mac2021 on 15/11/2021.
//

import UIKit

class equipeViewController: UIViewController {
    
    
    @IBOutlet weak var imageEquipe: UIImageView!
    @IBOutlet weak var nomEquipe: UILabel!
    @IBOutlet weak var nomLigue: UILabel!
    @IBOutlet weak var descEquipe: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func listJoueurBtn(_ sender: Any) {
    }
    
   

}
