//
//  PaymentViewController.swift
//  YassYes
//
//  Created by Mac2021 on 13/11/2021.
//

import UIKit

class PaymentViewController: UIViewController {

       
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
   
    
}
