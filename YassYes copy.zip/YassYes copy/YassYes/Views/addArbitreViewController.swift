//
//  addArbitreViewController.swift
//  YassYes
//
//  Created by Mac2021 on 15/11/2021.
//

import UIKit

class addArbitreViewController: UIViewController {
    
    
    @IBOutlet weak var imageArbitre: UIImageView!
    @IBOutlet weak var nomArbitre: UITextField!
    @IBOutlet weak var prenomArbitre: UITextField!
    @IBOutlet weak var ageArbitre: UITextField!
    @IBOutlet weak var numArbitre: UITextField!
    @IBOutlet weak var descArbitre: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func saveArbitreBtn(_ sender: Any) {
    }
    

}
