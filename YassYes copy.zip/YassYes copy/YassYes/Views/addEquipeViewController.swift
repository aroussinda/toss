//
//  addEquipeViewController.swift
//  YassYes
//
//  Created by Mac2021 on 15/11/2021.
//

import UIKit

class addEquipeViewController: UIViewController {
    
    
    @IBOutlet weak var imageEquipe: UIImageView!
    @IBOutlet weak var nomEquipe: UITextField!
    @IBOutlet weak var descEquipe: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func ajoutEquipeBtn(_ sender: Any) {
    }
    

}
