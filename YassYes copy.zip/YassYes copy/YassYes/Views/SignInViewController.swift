//
//  SignInViewController.swift
//  YassYes
//
//  Created by Mac2021 on 15/11/2021.
//

import UIKit
import GoogleSignIn

class SignInViewController: UIViewController ,GIDSignInUIDelegate{
    
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var motdepasse: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().signInSilently()
        let gSignIn = GIDSignInButton(frame: CGRect(x: 57, y: 671, width: 120, height: 70))
        view.addSubview(gSignIn)
    
        let signOut = UIButton (frame: CGRect(x: 220, y: 671, width: 120, height: 44))
        signOut.backgroundColor = UIColor.red
        signOut.setTitle("Sign out", for:  .normal)
        signOut.addTarget(self, action: #selector(self.signOut(sender:)), for: .touchUpInside)
        self.view.addSubview(signOut)

        // Do any additional setup after loading the view.
    }
    @objc func signOut(sender: UIButton)
    {
        print ("signOut")
        GIDSignIn.sharedInstance().signOut()
    }

    

    @IBAction func forgotPasswordBtn(_ sender: Any) {
    }
    
    @IBAction func signInBtn(_ sender: Any) {
    }
    @IBAction func signUpBtn(_ sender: Any) {
    }
    @IBAction func signUpGoogleBtn(_ sender: Any) {
    }
    
}
