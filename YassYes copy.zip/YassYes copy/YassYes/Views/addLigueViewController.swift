//
//  addLigueViewController.swift
//  YassYes
//
//  Created by Mac2021 on 15/11/2021.
//

import UIKit

class addLigueViewController: UIViewController {
    
    
    @IBOutlet weak var imageLigue: UIImageView!
    @IBOutlet weak var nomLigue: UITextField!
    @IBOutlet weak var nomStade: UITextField!
    @IBOutlet weak var descLigue: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

  

}
