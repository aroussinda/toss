//
//  modifierJoueurViewController.swift
//  YassYes
//
//  Created by Mac2021 on 15/11/2021.
//

import UIKit

class modifierJoueurViewController: UIViewController {
    
    
    @IBOutlet weak var nomJoueur: UITextField!
    @IBOutlet weak var prenomJoueur: UITextField!
    @IBOutlet weak var ageJoueur: UITextField!
    @IBOutlet weak var longJoueur: UITextField!
    @IBOutlet weak var poidsJoueur: UITextField!
    @IBOutlet weak var numJoueur: UITextField!
    @IBOutlet weak var descJoueur: UITextField!
    @IBOutlet weak var imageJoueur: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func updateJoueurBtn(_ sender: Any) {
    }
    

   

}
