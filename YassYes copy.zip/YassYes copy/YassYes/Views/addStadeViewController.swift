//
//  addStadeViewController.swift
//  YassYes
//
//  Created by Mac2021 on 15/11/2021.
//

import UIKit

class addStadeViewController: UIViewController {
    
    @IBOutlet weak var imageStade: UIImageView!
    @IBOutlet weak var nomStade: UITextField!
    @IBOutlet weak var descStade: UITextField!
   
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func saveStadeBtn(_ sender: Any) {
    }
    

}
