//
//  DetailsControllerViewController.swift
//  Worskhop UITabView
//
//  Created by Nouha on 10/12/21.
//  Copyright © 2021 Nouha. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {

    
    //var
    var movieName: String?
    
    
    //Widgets
    
    @IBOutlet weak var movieImg: UIImageView!
    
    @IBOutlet weak var movieTitle: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        movieImg.image = UIImage(named: movieName!)
        movieTitle.text = movieName!
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
