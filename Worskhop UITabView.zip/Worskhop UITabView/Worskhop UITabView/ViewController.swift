//
//  ViewController.swift
//  Worskhop UITabView
//
//  Created by Nouha on 10/6/21.
//  Copyright © 2021 Nouha. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate{
    
    

    
    var data = ["EL Camino","Extraction","Project Power","Six Underground","Spenser Confidential","The Irishman"]
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return data.count
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "mCell")
           let contentView = cell?.contentView
           
           let label = contentView?.viewWithTag(2) as! UILabel
           let Image = contentView?.viewWithTag(1) as! UIImageView
           
           label.text = data[indexPath.row]
           Image.image = UIImage(named : data[indexPath.row])
           
           return cell!
       }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
   //Cellule OnClickListener
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let movie = data[indexPath.row]
        performSegue(withIdentifier: "mSegue", sender: movie)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let movie = sender as! String
        let destination = segue.destination as! DetailsViewController
        destination.movieName = movie
        
    }
    
    
    


}

