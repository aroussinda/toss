//
//  FormationModel.swift
//  success
//
//  Created by Apple Esprit on 28/11/2021.
//

import Foundation

struct Formation :Encodable {
    
    internal init(_id: String? = nil, nomFormateur: String, nomFormation: String, prix: Float, description: String) {
        self._id = _id
        self.nomFormateur = nomFormateur
        self.nomFormation = nomFormation
        self.prix = prix
        self.description = description
    }
    
    var _id: String?
    var nomFormateur : String
    var nomFormation: String
    var prix : Float
    var description : String
    
}
