//
//  User.swift
//  success
//
//  Created by Apple Esprit on 26/11/2021.
//

import Foundation

struct User : Codable {
    
    internal init(_id: String? = nil, nom: String, username: String, email: String, password: String? = nil, role: String) {
        self._id = _id
        self.nom = nom
        self.username = username
        self.email = email
        self.password = password
        self.role = role
    }
    
    var _id: String?
    var nom : String
    var username : String
    var email : String
    var password : String?
    var role : String
    
}
