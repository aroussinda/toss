//
//  panier.swift
//  success
//
//  Created by Apple Esprit on 26/11/2021.
//

import Foundation

struct Panier : Encodable{
    
    internal init(_id: String? = nil, formations: [Formation]) {
        self._id = _id
        self.formations = formations
    }
    
    var _id: String?
    var formations : [Formation]
    
}
