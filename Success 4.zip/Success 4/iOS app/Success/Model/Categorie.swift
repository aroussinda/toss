//
//  Cours.swift
//  success
//
//  Created by Apple Esprit on 26/11/2021.
//

import Foundation

struct Categorie : Encodable {
    
    internal init(_id: String? = nil, nom: String, image: String) {
        self._id = _id
        self.nom = nom
        self.image = image
    }
    
    var _id: String?
    var nom: String
    var image : String
    
}
