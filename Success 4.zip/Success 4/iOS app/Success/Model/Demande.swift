//
//  Demande.swift
//  success
//
//  Created by Apple Esprit on 26/11/2021.
//

import Foundation

struct Demande: Encodable  {
    
    internal init(_id: String? = nil, nom: String, cv: String, etat: Int, user: User? = nil) {
        self._id = _id
        self.nom = nom
        self.cv = cv
        self.etat = etat
        self.user = user
    }
    
    var _id: String?
    var nom : String
    var cv : String
    var etat : Int
    var user: User?
    
}
