//
//  ForgotpasswordViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class ForgotpasswordViewController: UIViewController {
    
    
    @IBOutlet weak var lastPass: UITextField!
    @IBOutlet weak var newpass: UITextField!
    @IBOutlet weak var confirmpass: UITextField!
    @IBOutlet weak var signinn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        func validateFieds() -> String? {
            //chek that all fields are filled in
            if lastPass.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || newpass.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || confirmpass.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
                return "Please fill in all fields."
            }
            // chek if the password is secure
            let cleanedPassword = newpass.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            
            if utilites.isPasswordValid(cleanedPassword) == false {
                // password isn't secure enough
                return "please make sure your password is at least 8 caracters, contains a special characters and a number."
            }
            return nil
        }
    }
    
    
    
    @IBAction func signinTapped(_ sender: Any) {
        
        
        if lastPass.text == "" || newpass.text == "" || confirmpass.text == "" {
            
            self.showAlert(title: "Missing info !", message: "Please make sure to fill all the form and try again")
            
        } else {
            
            let user = User(nom: "", username: "", email: "", password: lastPass.text!, role: "")
            
            /*  let lastpassword = lastPass.text!
             let newPassword = newpass.text!
             let confirmepass = confirmpass.text!
             */
            
            UserViewModel.sharedInstance.register(user: user){ (isSuccess) in
                if isSuccess{
                    self.performSegue(withIdentifier: "seg00", sender: IndexPath.self)
                } else {
                    self.showAlert(title: "Failure", message: "invalid Credentials")
                }
            }
        }
    }
    
    
    
    func showAlert(title:String, message:String){
        
        let alert = UIAlertController(title: title, message: message,preferredStyle: .alert)
        
        let action = UIAlertAction(title:"ok", style: .cancel, handler:nil)
        
        alert.addAction(action)
        
        self.present(alert, animated: true, completion: nil)
        
        
        
    }
}
