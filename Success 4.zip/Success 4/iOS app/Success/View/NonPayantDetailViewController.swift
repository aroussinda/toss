//
//  DetailViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit
import Braintree

class NonPayantDetailViewController: UIViewController {
    
    var formation : Formation?
    
    @IBOutlet weak var nomFormation: UILabel!
    @IBOutlet weak var nomFormateur: UILabel!
    @IBOutlet weak var prixFormation: UILabel!
    @IBOutlet weak var descriptionFormation: UILabel!
    
    @IBOutlet weak var textView: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initialize()
    }
    
    
    func initialize() {
        nomFormation.text = "Formation : " + formation!.nomFormation
        nomFormateur.text = "Formateur : " + formation!.nomFormateur
        prixFormation.text = "Prix : " + String((formation?.prix)!)
        textView.isEditable = false
        textView.dataDetectorTypes = .link
        textView.text =  formation!.description
    }
}


