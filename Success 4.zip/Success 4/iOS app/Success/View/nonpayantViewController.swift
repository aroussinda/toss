//
//  nonpayantViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class nonpayantViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    // VARS
    var formations : [Formation] = []
    var formation : Formation?
    
    // WIDGETS
    @IBOutlet weak var formationsTableView: UITableView!
    
    // PROTOCOLS
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailsSegue" {
            let destination = segue.destination as! NonPayantDetailViewController
            destination.formation = formation
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return formations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "mCell")
        let contentView = cell!.contentView
        
        let nomFormationLabel = contentView.viewWithTag(1) as! UILabel
        
        let formation = formations[indexPath.row]
        
        nomFormationLabel.text = formation.nomFormation
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        formation = formations[indexPath.row]
        performSegue(withIdentifier: "detailsSegue", sender: formation)
    }
    
    // LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        initialize()
    }
    
    // METHODS
    func initialize() {
        FormationViewModel().getAll { [self] success, formationsfromRep in
            if success {
                self.formations = []
                for formation in formationsfromRep! {
                    if formation.prix == 0 {
                        formations.append(formation)
                    }
                }
                
                self.formationsTableView.reloadData()
            }else {
                self.present(Alert.makeAlert(titre: "Error", message: "Could not load formations "),animated: true)
            }
        }
    }
    
    // ACTIONS
    @IBAction func refresh(_ sender: Any) {
        initialize()
    }
    
}
