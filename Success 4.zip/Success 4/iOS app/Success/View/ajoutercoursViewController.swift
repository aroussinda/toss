//
//  ajoutercoursViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class ajoutercoursViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    // VARS
    var categories : [Categorie] = []
    var selectedCategory : Categorie?
    
    // WIDGETS
    @IBOutlet weak var categoriesTableView: UITableView!
    @IBOutlet weak var nomCourTF: UITextField!
    
    @IBOutlet weak var contentCours: UITextField!
    // PROTOCOLS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categories.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "mCell")
        let contentView = cell!.contentView
        let categorieImage = contentView.viewWithTag(1) as! UIImageView
        let nomLabel = contentView.viewWithTag(2) as! UILabel
        
        categorieImage.layer.cornerRadius = ROUNDED_RADIUS
        nomLabel.text = categories[indexPath.row].nom
        
        let categorie = categories[indexPath.row]
        
        ImageLoader.shared.loadImage(
            identifier: categorie.image,
            url: HOST_IMAGES + categorie.image,
            completion: { [] image in
                categorieImage.image = image
            })
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedCategory = categories[indexPath.row]
    }
    
    // LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        initialize()
    }
    
    // METHODS
    func initialize() {
        CategorieViewModel().getAll { success, categoriesfromRep in
            if success {
                self.categories = categoriesfromRep!
                self.categoriesTableView.reloadData()
            }else {
                self.present(Alert.makeAlert(titre: "Error", message: "Could not load categories "),animated: true)
            }
        }
    }
    
    // ACTIONS
    @IBAction func refresh(_ sender: Any) {
        initialize()
    }
    
    @IBAction func ajouBtton(_ sender: Any) {
        
        if nomCourTF.text!.isEmpty  {
            self.present(Alert.makeAlert(titre: "Avertissement", message: "Champs vides"),animated: true)
            return
        }
        
        if selectedCategory == nil {
            self.present(Alert.makeAlert(titre: "Alert", message: "please choose a category"), animated: true)
            return
        }
        
        let cour = Cour(nom: nomCourTF.text!, categorie: selectedCategory!, pdf: "", description: contentCours.text!)
        CourViewModel.sharedInstance.add(cour: cour) { sucess in
            if sucess{
                self.performSegue(withIdentifier: "voirCours", sender: self)
            }else{
                print("")
            }
        }
    }
}
