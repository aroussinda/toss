//
//  CategorieViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class CategorieViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    // VARS
    var categories : [Categorie] = []
    var cours: [Cour] = []
    
    // WIDGETS
    @IBOutlet weak var categoriesTableView: UITableView!
    
    // PROTOCOLS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categories.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "mCell")
        let contentView = cell!.contentView
        let categorieImage = contentView.viewWithTag(1) as! UIImageView
        let nomLabel = contentView.viewWithTag(2) as! UILabel
        
        categorieImage.layer.cornerRadius = ROUNDED_RADIUS
        nomLabel.text = categories[indexPath.row].nom
        
        let categorie = categories[indexPath.row]
        
        ImageLoader.shared.loadImage(
            identifier: categorie.image,
            url: HOST_IMAGES + categorie.image,
            completion: { [] image in
                categorieImage.image = image
            })
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let selectedCategory = categories[indexPath.row]
        
        CourViewModel.sharedInstance.getAll { success, coursFromRep in
            
            self.cours = []
            
            for cour in coursFromRep! {
                if cour.categorie._id == selectedCategory._id {
                    self.cours.append(cour)
                }
            }
            
            self.performSegue(withIdentifier: "afficherCour", sender: self.cours)
        }
    }
    
    // LIFECYCLE
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "voirCours" {
//            let destination = segue.destination as! CoursParCategorieViewController
//            destination.cours = cours
//        }
//    }
//    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        initialize()
    }
    
    // METHODS
    func initialize() {
        CategorieViewModel().getAll { success, categoriesfromRep in
            if success {
                self.categories = categoriesfromRep!
                self.categoriesTableView.reloadData()
            }else {
                self.present(Alert.makeAlert(titre: "Error", message: "Could not load categories "),animated: true)
            }
        }
    }
    
    // ACTIONS
    @IBAction func refresh(_ sender: Any) {
        initialize()
    }
    
}
