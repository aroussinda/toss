//
//  AjoutCategorieView.swift
//  success
//
//  Created by Apple Mac on 23/12/2021.
//

import Foundation
import UIKit

class AjoutCategorieView: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    // VAR
    var currentPhoto : UIImage?
    
    @IBOutlet weak var categorieImage: UIImageView!
    @IBOutlet weak var nomCategorieTF: UITextField!
    
    // PROTOCOLS
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        guard let selectedImage = info[.originalImage] as? UIImage else {
            
            return
        }
        
        currentPhoto = selectedImage
        categorieImage.image = selectedImage
        
        self.dismiss(animated: true, completion: nil)
    }
    
    // LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // METHODS
    func camera() {
        let myPickerControllerCamera = UIImagePickerController()
        myPickerControllerCamera.delegate = self
        myPickerControllerCamera.sourceType = UIImagePickerController.SourceType.camera
        myPickerControllerCamera.allowsEditing = true
        self.present(myPickerControllerCamera, animated: true, completion: nil)
    }
    
    
    func gallery() {
        let myPickerControllerGallery = UIImagePickerController()
        myPickerControllerGallery.delegate = self
        myPickerControllerGallery.sourceType = UIImagePickerController.SourceType.photoLibrary
        myPickerControllerGallery.allowsEditing = true
        self.present(myPickerControllerGallery, animated: true, completion: nil)
    }
    
    func showActionSheet(){
        
        let actionSheetController: UIAlertController = UIAlertController(title: NSLocalizedString("Upload Image", comment: ""), message: nil, preferredStyle: .actionSheet)
        actionSheetController.view.tintColor = UIColor.black
        let cancelActionButton: UIAlertAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel) { action -> Void in
            print("Cancel")
        }
        actionSheetController.addAction(cancelActionButton)
        
        let saveActionButton: UIAlertAction = UIAlertAction(title: NSLocalizedString("Take Photo", comment: ""), style: .default)
        { action -> Void in
            self.camera()
        }
        actionSheetController.addAction(saveActionButton)
        
        let deleteActionButton: UIAlertAction = UIAlertAction(title: NSLocalizedString("Choose From Gallery", comment: ""), style: .default)
        { action -> Void in
            self.gallery()
        }
        
        actionSheetController.addAction(deleteActionButton)
        self.present(actionSheetController, animated: true, completion: nil)
    }
    
    // ACTIONS
    @IBAction func changePhoto(_ sender: Any) {
        showActionSheet()
    }
    
    @IBAction func add(_ sender: Any) {
        
        if (currentPhoto == nil){
            self.present(Alert.makeAlert(titre: "Avertissement", message: "Choisir une image"), animated: true)
            return
        }
        
        CategorieViewModel.sharedInstance.add(categorie: Categorie(nom: nomCategorieTF.text!, image: ""),uiImage: currentPhoto!) { success in
            if success {
                self.present(Alert.makeActionAlert(titre: "Success", message: "Categorie ajouté", action: UIAlertAction(title: "Ok", style: .default, handler: { uiAction in
                    self.dismiss(animated: true, completion: nil)
                })),animated: true)
            }
        }
    }
    
}
