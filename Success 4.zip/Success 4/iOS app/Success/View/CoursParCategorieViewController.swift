//
//  CoursViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit
import PDFKit

class CoursParCategorieViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var cours : [Cour]?
    
    @IBOutlet weak var tableview: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cours!.count
    }
    
    override func viewDidAppear(_ animated: Bool) {
        tableview.reloadData()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "mCell")
        let contentView = cell?.contentView
        let nomCour = contentView?.viewWithTag(1) as! UILabel
         
        nomCour.text = cours![indexPath.row].nom
        return cell!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
