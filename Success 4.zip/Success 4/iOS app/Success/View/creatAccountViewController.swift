//
//  creatAccountViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class creatAccountViewController: UIViewController {
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var adressmailTextFIeld: UITextField!
    @IBOutlet weak var passwTextFIeld: UITextField!
    @IBOutlet weak var conPassTextField: UITextField!
    @IBOutlet weak var sigUpButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func sigUpButton(_ sender: Any) {
        
        
        if nameTextField.text == "" || usernameTextField.text == "" || adressmailTextFIeld.text == ""  || passwTextFIeld.text == ""   || conPassTextField.text == "" {
            
            self.showAlert(title: "Missing info !", message: "Please make sure to fill all the form and try again")
            
        }else{
            
            let user = User(nom: nameTextField.text!, username: usernameTextField.text!, email: adressmailTextFIeld.text!, password: passwTextFIeld.text!, role: "User")
            
            UserViewModel.sharedInstance.register(user: user) { sucess in
                if sucess{
                    self.navigationController?.popToRootViewController(animated: true)
                    
                }else{
                    
                }
            }
        }}
    
    func showAlert(title:String, message:String){
        
        let alert = UIAlertController(title: title, message: message,preferredStyle: .alert)
        
        let action = UIAlertAction(title:"ok", style: .cancel, handler:nil)
        
        alert.addAction(action)
        
        self.present(alert, animated: true, completion: nil)
    }
}
