//
//  noInternetViewController.swift
//  success
//
//  Created by Apple Esprit on 4/1/2022.
//

import UIKit

class noInternetViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        testInternet()
        // Do any additional setup after loading the view.
    }
    
    func testInternet() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "homeVC") as! AcceulViewController
         reachability = try! Reachability()

        if reachability.connection == .unavailable {
          //  showAlert(title: "Internet Connectivity", message: "You seem to have a problem with your internet connection")
            
           
        } else {
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated:true, completion:nil)
        }
    }
    


}
