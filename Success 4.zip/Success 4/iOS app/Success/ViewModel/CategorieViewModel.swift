//
//  CategorieViewModel.swift
//  success
//
//  Created by Apple Esprit on 28/11/2021.
//


import SwiftyJSON
import Alamofire
import UIKit.UIImage

public class CategorieViewModel: ObservableObject{
    
    static let sharedInstance = CategorieViewModel()
    
    func getAll(completed: @escaping (Bool, [Categorie]?) -> Void) {
        AF.request(HOST + "categorie",
                   method: .get)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    var categories : [Categorie] = []
                    for categorie in JSON(response.data!)["categories"] {
                        categories.append(CategorieViewModel.sharedInstance.makeCategorie(jsonItem: categorie.1))
                    }
                    
                    completed(true, categories)
                case let .failure(error):
                    print(error)
                    completed(false, nil)
                }
            }
    }
    
    func add(categorie: Categorie, uiImage: UIImage, completed: @escaping (Bool) -> Void) {
        AF.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(uiImage.jpegData(compressionQuality: 0.5)!, withName: "image" , fileName: "image.jpeg", mimeType: "image/jpeg")
            
            for (key, value) in
                    [
                        "nom": categorie.nom,
                    ]
            {
                multipartFormData.append((value.data(using: .utf8))!, withName: key)
            }
            
        },to: HOST + "categorie",
                  method: .post)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Success")
                    completed(true)
                case let .failure(error):
                    completed(false)
                    print(error)
                }
            }
    }
    
    func edit(categorie: Categorie, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "categorie",
                   method: .put,
                   parameters: [
                    "_id": categorie._id!,
                    "nom": categorie.nom,
                    "image": categorie.image
                   ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func delete(categorie: Categorie, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "categorie",
                   method: .delete,
                   parameters: [ "_id": categorie._id! ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func makeCategorie(jsonItem: JSON) -> Categorie {
        Categorie(
            _id: jsonItem["_id"].stringValue,
            nom: jsonItem["nom"].stringValue,
            image: jsonItem["image"].stringValue
        )
    }
}

