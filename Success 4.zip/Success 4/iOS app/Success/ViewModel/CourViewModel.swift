//
//  coursservice.swift
//  success
//
//  Created by Apple Esprit on 2/12/2021.
//
import SwiftyJSON
import Alamofire
import UIKit.UIImage

public class CourViewModel: ObservableObject{
    
    static let sharedInstance = CourViewModel()
    
    func getAll(completed: @escaping (Bool, [Cour]?) -> Void) {
        AF.request(HOST + "cour",
                   method: .get)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    var cours : [Cour] = []
                    for cour in JSON(response.data!)["cours"] {
                        cours.append(CourViewModel.sharedInstance.makeCour(jsonItem: cour.1))
                    }
                    completed(true, cours)
                case let .failure(error):
                    print(error)
                    completed(false, nil)
                }
            }
    }
    
    func add(cour: Cour, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "cour",
                   method: .post,
                   parameters: [
                    "nom": cour.nom,
                    "categorie": cour.categorie._id!,
                    "pdf": cour.pdf,
                    "description": cour.description
                   ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func edit(cour: Cour, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "cour",
                   method: .put,
                   parameters: [
                    "_id": cour._id!,
                    "nom": cour.nom,
                    "categorie": cour.categorie,
                    "pdf": cour.pdf
                   ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func delete(cour: Cour, completed: @escaping (Bool) -> Void) {
        AF.request(HOST + "cour",
                   method: .delete,
                   parameters: [ "_id": cour._id! ],
                   encoding: JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
    
    func makeCour(jsonItem: JSON) -> Cour {
        Cour(
            _id: jsonItem["_id"].stringValue,
            nom: jsonItem["nom"].stringValue,
            categorie: CategorieViewModel.sharedInstance.makeCategorie(jsonItem: jsonItem["categorie"]),
            pdf: jsonItem["pdf"].stringValue,
            description: jsonItem["description"].stringValue
        )
    }
}
