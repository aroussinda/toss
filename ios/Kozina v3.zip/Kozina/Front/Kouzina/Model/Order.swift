//
//  Order.swift
//  Kouzina
//
//  Created by Apple Esprit on 12/12/2021.
//

import Foundation


struct Order {
    var _id: String?
    var type: String?
    var emplacement: String?
    var plat: String?
}
