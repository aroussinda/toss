//
//  Demande.swift
//  success
//
//  Created by Apple Esprit on 26/11/2021.
//

import Foundation
struct Demande: Encodable {

var nom : String?
    var cv : String?
    
    
    
    
}
