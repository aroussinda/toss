//
//  Cours.swift
//  success
//
//  Created by Apple Esprit on 26/11/2021.
//

import Foundation
struct Cours : Encodable {
    var categorie : String?
var nomcours: String?
    var pdf : String?
    
    
    
}
