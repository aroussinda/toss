//
//  panier.swift
//  success
//
//  Created by Apple Esprit on 26/11/2021.
//

import Foundation
struct panier : Encodable{
 
var produit : String?
    
    
    
}
