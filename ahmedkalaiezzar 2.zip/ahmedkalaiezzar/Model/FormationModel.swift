//
//  FormationModel.swift
//  success
//
//  Created by Apple Esprit on 28/11/2021.
//

import Foundation

struct FormationModel :Encodable {
    
    var nomFormateur : String?
    var nomFormation: String?
    var prix : Float?
    var description : String?
 
    
    
    
}
