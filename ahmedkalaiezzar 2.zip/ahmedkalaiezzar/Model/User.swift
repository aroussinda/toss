//
//  User.swift
//  success
//
//  Created by Apple Esprit on 26/11/2021.
//

import Foundation


struct User : Encodable {
    var nom : String?
var username : String?
    var email : String?
    var password : String?
    
    
    
}
