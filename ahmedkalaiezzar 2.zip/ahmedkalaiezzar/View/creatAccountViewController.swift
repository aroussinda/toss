//
//  creatAccountViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class creatAccountViewController: UIViewController {
    
    @IBOutlet weak var nameTextField: UITextField!
    
    
    @IBOutlet weak var usernameTextField: UITextField!
    
    
    @IBOutlet weak var adressmailTextFIeld: UITextField!
    
    
    @IBOutlet weak var passwTextFIeld: UITextField!
    
    
    @IBOutlet weak var conPassTextField: UITextField!
    
    @IBOutlet weak var sigUpButton: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    func validateFieds() -> String? {
        //chek that all fields are filled in
        if nameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || usernameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == ""  || adressmailTextFIeld.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || passwTextFIeld.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || conPassTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == ""{
            return "Please fill in all fields."
        }
        // chek if the password is secure
        let cleanedPassword = passwTextFIeld.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if utilites.isPasswordValid(cleanedPassword) == false {
            // password isn't secure enough
            return "please make sure your password is at least 8 caracters, contains a special characters and a number."
        }
        return nil
        
    }
    
    @IBAction func sigUpButton(_ sender: Any) {
      
        let user = User(nom: nameTextField.text!, username: usernameTextField.text!, email: adressmailTextFIeld.text!, password: passwTextFIeld.text!)
        UserserviceViewmodel().inscription(User: user) { sucess in
            if sucess{
                self.performSegue(withIdentifier: "seg7", sender: self)
                
            }else{
                print("")
            }
        }
  }
    
    
}
