//
//  ListecoursInfoViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class ListecoursInfoViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var data = ["ios","nodejs","java","flutter"]

    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mCell")
        let contentView = cell?.contentView
        let Label = contentView?.viewWithTag(1) as! UILabel
        let imageView = contentView?.viewWithTag(2) as! UIImageView
        Label.text = data[indexPath.row]
        imageView.image = UIImage(named: data[indexPath.row])
    return cell!
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        let cour =  data[indexPath.row]
        performSegue(withIdentifier: "seg100", sender: cour)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let Label = sender as! String
        let destination = segue.destination as! CoursViewController
        destination.courTitle = Label
    }
}
