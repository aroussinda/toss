//
//  ajoutercoursViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class ajoutercoursViewController: UIViewController {
    @IBOutlet weak var categ: UITextField!
    
    @IBOutlet weak var nomcours: UITextField!
  
    @IBOutlet weak var ajoucours: UITextField!
    
    @IBOutlet weak var pdf: UITextField!
    
    @IBOutlet weak var ajoutcou: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func ajouBtton(_ sender: Any) {
        let cours = Cours(categorie: categ.text!, nomcours: nomcours.text!, pdf: pdf.text!)
        courserviceviewmodel().inscription(Cours: cours) { sucess in
            if sucess{
                self.performSegue(withIdentifier: "seg22", sender: self)

                
            }else{
                print("")
            }
        }
    }
}
