//
//  ForgotpasswordViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class ForgotpasswordViewController: UIViewController {
    

    @IBOutlet weak var lastPass: UITextField!
    
    
    @IBOutlet weak var newpass: UITextField!
  
    
    @IBOutlet weak var confirmpass: UITextField!
    

    @IBOutlet weak var signinn: UIButton!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        func validateFieds() -> String? {
            //chek that all fields are filled in
            if lastPass.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || newpass.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || confirmpass.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
                return "Please fill in all fields."
            }
            // chek if the password is secure
            let cleanedPassword = newpass.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            
            if utilites.isPasswordValid(cleanedPassword) == false {
                // password isn't secure enough
                return "please make sure your password is at least 8 caracters, contains a special characters and a number."
            }
            return nil

        // Do any additional setup after loading the view.
    
        
}
    
 
    }
    

        
    @IBAction func signinTapped(_ sender: Any) {
        performSegue(withIdentifier: "seg00", sender: self)
    }
    
    
   
}

