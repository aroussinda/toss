//
//  CoursViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit
import PDFKit

class CoursViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var courTitle : String?
    var pdfviewObject:PDFView = PDFView()
    var pdfDocumntObject:PDFDocument = PDFDocument()
    var totalPageCount = 0
    var dato = ["chapitre1","chapitre2","chapitre3"]
    var chap = ["tablViewController","collectionViewController","Cordata"]
    var ima = ["pdf","pdf","pdf"]
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dato.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mCell1")
        let contentView = cell?.contentView
        let cours = contentView?.viewWithTag(3) as! UILabel
        let chapt = contentView?.viewWithTag(8) as! UILabel
        chapt.text = chap[indexPath.row]
        cours.text = dato[indexPath.row]
        let imageView = contentView?.viewWithTag(9) as! UIImageView
        imageView.image = UIImage(named: ima[indexPath.row])
        return cell!
    }
    
    
    
    


    override func viewDidLoad() {
        super.viewDidLoad()
        pdfviewObject = PDFView(frame: self.view.bounds)
        self.view.addSubview(pdfviewObject)
        guard let path = Bundle.main.url(forResource: "courspdf", withExtension: "pdf")
        else
        {
         print("Error in PDF Path")
            return
        }
        pdfDocumntObject = PDFDocument(url: path)!
        pdfviewObject.autoScales = true
        pdfviewObject.displayMode = .singlePage
        pdfviewObject.displayDirection = .horizontal
        pdfviewObject.usePageViewController(true)
        totalPageCount = 0
        if let total = pdfviewObject.document?.pageCount {
            totalPageCount = total
        }
        NotificationCenter.default.addObserver(self, selector: #selector(countPages), name: Notification.Name.PDFViewPageChanged, object: nil)
        countPages()
    }
    
    @objc func countPages()
    {
        let currentPageNumber = pdfDocumntObject.index(for: pdfviewObject.currentPage!)+1
        let totalPage = "\(currentPageNumber)/\(totalPageCount)"
        title = "PDF Viewer \(totalPage)"
    }

}
