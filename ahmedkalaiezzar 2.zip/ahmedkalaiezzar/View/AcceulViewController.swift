//
//  AcceulViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class AcceulViewController: UIViewController {
    
    @IBOutlet weak var consulterButton: UIButton!
    
    @IBOutlet weak var AjouterButton: UIButton!
    
    
    @IBOutlet weak var consulterFButton: UIButton!
    
    
    @IBOutlet weak var ajouterfButton: UIButton!
    
    @IBOutlet weak var demande: UIButton!
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func consulterButton(_ sender: Any) {
  
    }
    @IBAction func AjouterButton(_ sender: Any) {
       
    }
    @IBAction func consulterFButton(_ sender: Any) {
        
    }
    @IBAction func ajouterfButton(_ sender: Any) {
    
    }
    
    @IBAction func demandetapped(_ sender: Any) {
    }
}
