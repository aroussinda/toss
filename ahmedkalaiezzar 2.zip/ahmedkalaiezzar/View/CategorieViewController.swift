//
//  CategorieViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit

class CategorieViewController: UIViewController {
    
    @IBOutlet weak var infoBuuton: UIButton!
    
    @IBOutlet weak var mathButton: UIButton!
    
    @IBOutlet weak var scienButton: UIButton!
    
    @IBOutlet weak var literButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func infoButton(_ sender: Any) {
        performSegue(withIdentifier: "seg14", sender: self)
        
    }
    
    @IBAction func mathButton(_ sender: Any) {
        performSegue(withIdentifier: "seg15", sender: self)
        
    }
    
    @IBAction func scienButton(_ sender: Any) {
        performSegue(withIdentifier: "seg16", sender: self)
    }
    @IBAction func literButton(_ sender: Any) {
        performSegue(withIdentifier: "seg17", sender: self)
    
    }
}
