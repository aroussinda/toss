//
//  LoginViewController.swift
//  success
//
//  Created by esprit on 9/11/2021.
//

import UIKit
import GoogleSignIn



class LoginViewController: UIViewController ,GIDSignInUIDelegate {
    

    
    @IBOutlet weak var hellolabel: UILabel!
    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passTextField: UITextField!
    

    @IBOutlet weak var chlogin: UIButton!
    
    

    @IBOutlet weak var forgetpass: UIButton!
    
    
    @IBOutlet weak var creataccount: UIButton!
    
    
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().signInSilently()
        let gSignIn = GIDSignInButton(frame: CGRect(x: 57, y: 671, width: 120, height: 70))
        view.addSubview(gSignIn)
    
        let signOut = UIButton (frame: CGRect(x: 220, y: 671, width: 120, height: 44))
        signOut.backgroundColor = UIColor.red
        signOut.setTitle("Sign out", for:  .normal)
        signOut.addTarget(self, action: #selector(self.signOut(sender:)), for: .touchUpInside)
        self.view.addSubview(signOut)
    
    }
    @objc func signOut(sender: UIButton)
    {
        print ("signOut")
        GIDSignIn.sharedInstance().signOut()
    }
    
    
    
    
    
    
    //chek the fields
    func validateFieds() -> String? {
        //chek that all fields are filled in
        if emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || passTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            return "Please fill in all fields."
        }
        // chek if the password is secure
        let cleanedPassword = passTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if utilites.isPasswordValid(cleanedPassword) == false {
            // password isn't secure enough
            return "please make sure your password is at least 8 caracters, contains a special characters and a number."
        }
        return nil
        
    }
    
    @IBAction func loginTapped(_ sender: Any) {
        
        //Validate the fields
        let error = validateFieds()
        if error != nil {
            //there is something wrong with the fields, show error message
            showError(error!)
            
        
        
            
        
        }
        //Creat the user
        
        // transition to the home screen
    

    
        
        performSegue(withIdentifier: "seg3", sender: self)
      }
    

    @IBAction func fogetttt(_ sender: Any) {
        performSegue(withIdentifier: "seg1", sender: self)
    }
    
    @IBAction func CreatAccountTapped(_ sender: Any) {
        performSegue(withIdentifier: "seg2", sender: self)
    }
    func showError(_ message:String){
     hellolabel.text = message
}
    @IBAction func signUpGoogleBtn(_ sender: Any) {
    }
    

    
}
