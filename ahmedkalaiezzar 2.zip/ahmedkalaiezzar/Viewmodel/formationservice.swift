//
//  formationservice.swift
//  success
//
//  Created by Apple Esprit on 28/11/2021.
//


import SwiftyJSON
import Alamofire
import UIKit.UIImage

public class FormationserviceViewmodel: ObservableObject{
    
   
    
    func inscription(FormationModel: FormationModel, completed: @escaping (Bool) -> Void) {
        AF.request("http://192.168.163.200:3000/api/formation/storeFOR",
                   method: .post,
                   parameters: [
                    "nomFormateur": FormationModel.nomFormateur!,
                    "nomFormation": FormationModel.nomFormation!,
                    "prix": FormationModel.prix!,
                    "description": FormationModel.description!,
                   
                   ])
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
}

