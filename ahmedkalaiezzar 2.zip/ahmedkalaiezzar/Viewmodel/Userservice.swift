//
//  Userservice.swift
//  success
//
//  Created by Apple Esprit on 2/12/2021.
//

import Foundation
import SwiftyJSON
import Alamofire
import UIKit.UIImage

public class UserserviceViewmodel: ObservableObject{
    
   
    
    func inscription(User: User, completed: @escaping (Bool) -> Void) {
        AF.request("http://192.168.163.200:3000/api/user/register",
                   method: .post,
                   parameters: [
                    "nom": User.nom!,
                    "username": User.username!,
                    "email": User.email!,
                    "password": User.password!,
                   
                   ])
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
}
