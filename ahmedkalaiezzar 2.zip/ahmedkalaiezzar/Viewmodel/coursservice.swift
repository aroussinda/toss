//
//  coursservice.swift
//  success
//
//  Created by Apple Esprit on 2/12/2021.
//
import SwiftyJSON
import Alamofire
import UIKit.UIImage

public class courserviceviewmodel: ObservableObject{
    
   
    
    func inscription(Cours: Cours, completed: @escaping (Bool) -> Void) {
        AF.request("http://192.168.163.200:3000/api/cours/storeFOR",
                   method: .post,
                   parameters: [
                    "categ": Cours.categorie!,
                    "nomcours": Cours.nomcours!,
                    "pdf": Cours.pdf!,
            
                 
                   ])
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                switch response.result {
                case .success:
                    print("Validation Successful")
                    completed(true)
                case let .failure(error):
                    print(error)
                    completed(false)
                }
            }
    }
}
